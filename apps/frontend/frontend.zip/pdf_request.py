import fitz  # PyMuPDF
import requests
from io import BytesIO
import streamlit as st

# Function to download the PDF from the URL, search for the term, and return the pages where it's found
def find_search_term_in_pdf_from_url(pdf_url, search_term):
    # Step 1: Download the PDF
    response = requests.get(pdf_url)
    if response.status_code != 200:
        return None  # Return None if download fails or handle error appropriately
    # Step 2: Open the downloaded PDF with PyMuPDF
    pdf_data = BytesIO(response.content)
    doc = fitz.open(stream=pdf_data, filetype="pdf")
    # Step 3: Search for the term in the PDF and store the page numbers where it's found
    
    pages_with_term = []
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        text = page.get_text("text")
        if search_term.lower() in text.lower():
            pages_with_term.append(page_num + 1)  # Store page numbers (1-based indexing)

    # Step 4: Close the PDF document
    doc.close()

    # Return the list of page numbers where the search term is found
    return pages_with_term